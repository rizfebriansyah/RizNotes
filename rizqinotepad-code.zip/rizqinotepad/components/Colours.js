export default {
    MAIN: '#ffc000',
    NAME: '#610c31',
    BTN: '#ff0000',
    DARK: '#5b5b5b',
    LIGHT: '#fffcfc',
  };
  